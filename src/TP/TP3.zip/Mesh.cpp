#include "Mesh.hpp"
#include "Mesh_IO.hpp"

int counter_create = 0;
template <typename T>
T Mesh::compute_laplacian(unsigned int indice, const std::vector<T> &curr_weigh)
{

    // Récupère l'index des faces
    Mesh::Circulator_Face circ = this->incident_faces(indice);
    // Récupérer le premier indice
    unsigned int previous_face = *circ;

    circ++;

    T total = T();
    double area = 0.0;
    int fail = 0;
    for (int i = 0; i < circ.size(); ++circ, ++i)
    {

        unsigned int local_indice = return_local_indices(faces[*circ], indice);
        unsigned int previous_local_indice = return_local_indices(faces[previous_face], indice);

        unsigned vert_right = faces[*circ].vertices[(local_indice + 2) % 3];
        unsigned vert_left = faces[previous_face].vertices[(previous_local_indice + 1) % 3];
        unsigned vert_opposite = faces[*circ].vertices[(local_indice + 1) % 3];

        // Some  check to skip treatment of 0 and 0
        // Mainly created to test with double
        if (curr_weigh[vert_opposite] == 0 && curr_weigh[indice] == 0)
        {
            // Update the face reused
            previous_face = *circ;
            // std::cout << "nna" << std::endl;
            fail++;
            if (fail == circ.size())
            {
                total = T();
                area = 1;
                return T();
            }
            continue;
        }

        // Skip multipl computation, so.. ok ?
        Vertices vector_left_i = vertices[indice] - vertices[vert_left];
        Vertices vector_left_j = vertices[vert_opposite] - vertices[vert_left];
        Vertices vector_right_i = vertices[indice] - vertices[vert_right];
        Vertices vector_right_j = vertices[vert_opposite] - vertices[vert_right];

        // Left
        double cos_left = dotProduct(vector_left_i, vector_left_j) / (magn(vector_left_i) * magn(vector_left_j));
        double sin_left = std::sqrt(1 - (cos_left * cos_left));
        double cot_left = (sin_left != 0) ? (cos_left / sin_left) : 0;
        // RIght
        double cos_right = dotProduct(vector_right_i, vector_right_j) / (magn(vector_right_i) * magn(vector_right_j));
        double sin_right = std::sqrt(1 - (cos_right * cos_right));
        double cot_right = (sin_right != 0) ? (cos_right / sin_right) : 0;
        // Distance
        T distance = (curr_weigh[vert_opposite] - curr_weigh[indice]);

        total = total + (distance * (cot_right + cot_left));

        // Area approximation
        area = area + magn((crossProduct(vector_right_i, vector_right_j))) / 2.0f;

        previous_face = *circ;
    }

    T laplacian = (total) * (1 / (2 * area));

    return laplacian;
}

template <typename T>
T Mesh::compute_laplacian_with_function(unsigned int indice, std::function<T(const Mesh &, unsigned &indice_a, unsigned &indice_b)> function) const
{

    // Récupère l'index des faces
    Mesh::Circulator_Face circ = this->incident_faces(indice);
    // Récupérer le premier indice
    unsigned int previous_face = *circ;
    // Skip the first indice
    // std::cout << circ.size();
    circ++;

    T total = T();
    double area = 0.0;

    for (int i = 0; i < circ.size(); ++circ, ++i)
    {
        unsigned int local_indice = return_local_indices(faces[*circ], indice);
        unsigned int previous_local_indice = return_local_indices(faces[previous_face], indice);

        unsigned vert_right = faces[*circ].vertices[(local_indice + 2) % 3];
        unsigned vert_left = faces[previous_face].vertices[(previous_local_indice + 1) % 3];
        unsigned vert_opposite = faces[*circ].vertices[(local_indice + 1) % 3];

        // Skip multipl computation, so.. ok ?
        Vertices vector_left_i = vertices[indice] - vertices[vert_left];
        Vertices vector_left_j = vertices[vert_opposite] - vertices[vert_left];
        Vertices vector_right_i = vertices[indice] - vertices[vert_right];
        Vertices vector_right_j = vertices[vert_opposite] - vertices[vert_right];

        // Left
        double cos_left = dotProduct(vector_left_i, vector_left_j) / (magn(vector_left_i) * magn(vector_left_j));
        double sin_left = std::sqrt(1 - (cos_left * cos_left));
        double cot_left = (sin_left != 0) ? (cos_left / sin_left) : 0;
        // RIght
        double cos_right = dotProduct(vector_right_i, vector_right_j) / (magn(vector_right_i) * magn(vector_right_j));
        double sin_right = std::sqrt(1 - (cos_right * cos_right));
        double cot_right = (sin_right != 0) ? (cos_right / sin_right) : 0;

        // Distance
        T distance = function(*this, indice, vert_opposite);

        total = total + (distance * (cot_right + cot_left));

        // Area approximation
        area = area + magn((crossProduct(vector_right_i, vector_right_j))) / 3.0f;

        previous_face = *circ;
    }

    T laplacian = (total) * (1 / (2 * area));

    // std::cout << "Vertices: " << indice << " Laplacien : " << laplacian << std::endl;
    // std::cout << "total: " << total << " area : " << area << std::endl;

    return laplacian;
}

std::vector<Vertices> Mesh::compute_laplacian_vects() const
{
    std::vector<Vertices> laplacian;
    auto compute_distance_vect = [&](const Mesh &mesh, unsigned int &indice_a, unsigned int &indice_b)
    {
        return mesh.vertices[indice_b] - mesh.vertices[indice_a];
    };

    for (int i = 0; i < vertices.size(); i++)
    {
        laplacian.push_back(compute_laplacian_with_function<Vertices>(i, compute_distance_vect));
    }
    return laplacian;
}
std::vector<Vertices> Mesh::compute_mesh_normal()
{
    std::vector<Vertices> laplace_abcisse = this->compute_laplacian_vects();
    std::vector<Vertices> normals;

    for (int i = 0; i < laplace_abcisse.size(); i++)
    {
        // Stuff to control signedness
        unsigned int local_indice = return_local_indices(faces[vertices[i].face], i);
        unsigned vert_right = faces[vertices[i].face].vertices[(local_indice + 2) % 3];
        unsigned vert_left = faces[vertices[i].face].vertices[(local_indice + 1) % 3];
        Vertices vector_left = vertices[vert_left] - vertices[i];
        Vertices vector_right = vertices[vert_right] - vertices[i];
        Vertices correct_direction_normal = crossProduct(vector_left, vector_right);

        // Laplacian normal
        Vertices normal = ((laplace_abcisse[i]) / magn(laplace_abcisse[i]));
        normals.push_back((laplace_abcisse[i]) / magn(laplace_abcisse[i]) // Multiply by coorrect sign
                          * (2 * (dotProduct(correct_direction_normal, normal) <= 0) - 1));
        // TBF you can toggle this check off to funny
    }

    return normals;
}

std::vector<float> Mesh::compute_mean_curvature_f()
{
    std::vector<Vertices> laplace_abcisse = this->compute_laplacian_vects();
    std::vector<float> mean_curvature;

    for (int i = 0; i < laplace_abcisse.size(); i++)
    {
        mean_curvature.push_back(magn(laplace_abcisse[i]) / 2);
    }

    return mean_curvature;
}

// Averaging using laplacian and cros product
std::vector<Vertices> Mesh::compute_mesh_normal_test()
{
    std::vector<Vertices> vertex_normals = std::vector<Vertices>(vertices.size());
    for (int i = 0; i < vertex_normals.size(); i++)
    {
        unsigned int incident_face = vertices[i].face;
        unsigned int loc_indice = return_local_indices(faces[incident_face], i);
        unsigned vert_right = faces[incident_face].vertices[(loc_indice + 2) % 3];
        unsigned vert_left = faces[incident_face].vertices[(loc_indice + 1) % 3];
        vertex_normals[i] = crossProduct(vertices[vert_right], vertices[vert_left]);
        vertex_normals[i] = vertex_normals[i] / magn(vertex_normals[i]);
    }
    return vertex_normals;
}

void Mesh::mesh_heat_diffusion(float time_step)
{
    std::vector<double> laplacian_tab_now = std::vector<double>(vertices.size());

    // Vertices 0 get a value
    laplacian_tab_now[0] = 100.0;
    int time = 0;
    // std::cout << laplacian_tab_now.size();
    // Start measuring time

    while (time < 150)
    {
        time++;
        for (int i = 1; i < laplacian_tab_now.size(); i++)
        {
            laplacian_tab_now[i] = laplacian_tab_now[i] + (compute_laplacian(i, laplacian_tab_now) * time_step);
            laplacian_tab_now[0] = 100.0;
        }
        std::cout << time << std::endl;
    }
    for (int i = 0; i < laplacian_tab_now.size(); i++)
    {
        if (laplacian_tab_now[i] == 0)
        {
            continue;
        }
        std::cout << "Result heat: " << i << std::endl;

        std::cout << laplacian_tab_now[i] << std::endl;
    }

    return;
}

// TODO: On a vertice at  the convex hull, the faces will simply stop and not try to rotate further
Mesh::Circulator_Face Mesh::incident_faces(unsigned &vertices_indices) const
{
    // Procédé
    // On récupère la face incidente et on s'y rend
    // D'elle on prend l'une des deux faces gauche ou droite ne correspondant pas à l'indices
    // On récupère l'indice local du vertex sur cette face
    auto right_face = [&](const unsigned &indices)
    {
        return (indices + 2) % 3;
    };
    auto left_face = [&](const unsigned &indices)
    {
        return (indices + 1) % 3;
    };
    // Store in a vector the very all the indices of face bordering the vertices
    std::vector<unsigned> border_faces;

    // TODO: More or lessbad stop gap measure
    std::set<unsigned> border_faces_set;

    border_faces.push_back(vertices[vertices_indices].face);

    // Identify local indices in the incident face
    unsigned vert_loc_indices = return_local_indices(faces[border_faces[0]], vertices_indices);

    // Jumping to another face from this from one direction
    unsigned curr_face = getNeighbors(faces[vertices[vertices_indices].face], vert_loc_indices, left_face);
    // Circling in the loop face from another direction

    int count = 0;
    while (vertices[vertices_indices].face != curr_face)
    {
        if (!border_faces_set.emplace(curr_face).second)
        {
            break;
        }
        unsigned previous_face = curr_face;
        count++;
        // Recuperate current face local indices
        // We always turn while considering the original vertices as an anchor point
        vert_loc_indices = return_local_indices(faces[curr_face], vertices_indices);
        if (vert_loc_indices == 3)
        {
            break;
        }
        // Push back current face
        border_faces.push_back(curr_face);
        curr_face = getNeighbors(faces[curr_face], vert_loc_indices, left_face);
        if (curr_face == previous_face)
        {
            break; // Convexhull
        }
    }

    return Circulator_Face(border_faces, 0, vertices_indices);
}

// TODO: On a vertice at  the convex hull, the faces will simply stop and not try to rotate further
Mesh::Circulator_Face Mesh::incident_faces_convex(unsigned &vertices_indices) const
{
    auto right_face = [&](const unsigned &indices)
    {
        return (indices + 2) % 3;
    };
    auto left_face = [&](const unsigned &indices)
    {
        return (indices + 1) % 3;
    };
    // Store in a vector the very all the indices of face bordering the vertices
    std::vector<unsigned> border_faces;
    std::set<unsigned> border_faces_set;

    unsigned int start_face = vertices[vertices_indices].face;
    border_faces.push_back(start_face);
    border_faces_set.insert(start_face);
    // Identify local indices in the incident face
    unsigned vert_loc_indices = return_local_indices(faces[border_faces[0]], vertices_indices);
    // Function to get the next face in a specified direction (left or right)
    auto get_next_face = [&](unsigned curr_face, unsigned vert_loc_indices, bool left)
    {
        std::function<unsigned(const unsigned &)> direction;

        if (left)
        {
            direction = left_face;
        }
        else
        {
            direction = right_face;
        }
        return getNeighbors(faces[curr_face], vert_loc_indices, direction);
    };
    auto traverse_faces = [&](bool go_left)
    {
        unsigned curr_face = start_face;
        unsigned vert_loc_indices = return_local_indices(faces[curr_face], vertices_indices);

        while (true)
        {
            curr_face = get_next_face(curr_face, vert_loc_indices, go_left);
            if (curr_face == start_face || !border_faces_set.insert(curr_face).second)
            {
                break;
            }
            border_faces.push_back(curr_face);
            vert_loc_indices = return_local_indices(faces[curr_face], vertices_indices);
            if (vert_loc_indices == 3)
            {
                break;
            }
        }
    };
    traverse_faces(true);  // Traverse to the left
    traverse_faces(false); // Traverse to the right
    return Circulator_Face(border_faces, 0, vertices_indices);
}

Mesh::Circulator_Vertices Mesh::incident_vertices(unsigned &vertices_indices) const
{
    auto right_vertices = [&](const unsigned &indices)
    {
        return (indices + 2) % 3;
    };
    auto left_vertices = [&](const unsigned &indices)
    {
        return (indices + 1) % 3;
    };
    // Store in a vector the very all the indices of face bordering the vertices
    std::vector<unsigned> border_vertices;
    unsigned int adjacent_face = vertices[vertices_indices].face;
    // Identify local indices in the incident face
    unsigned vert_loc_indices = return_local_indices(faces[adjacent_face], vertices_indices);
    border_vertices.push_back(faces[adjacent_face].vertices[right_vertices(vert_loc_indices)]);

    unsigned curr_face = getNeighbors(faces[adjacent_face], vert_loc_indices, left_vertices);

    // Jumping to another face from this from one direction
    int i = 0;
    // Circling in the loop face from another direction
    while (vertices[vertices_indices].face != curr_face)
    {
        i++;
        vert_loc_indices = return_local_indices(faces[curr_face], vertices_indices);
        if (vert_loc_indices == 3)
        {
            break;
        }
        curr_face = getNeighbors(faces[curr_face], vert_loc_indices, left_vertices);
        border_vertices.push_back(faces[curr_face].vertices[left_vertices(vert_loc_indices)]);
    }

    return Circulator_Vertices(border_vertices, 0, vertices_indices);
}

void Mesh::extractEdges(std::queue<Edges> &edge_queue)
{
    edge_queue = std::queue<Edges>();
    std::unordered_set<Edges, Edges::Edgeshash> edge_set;
    int face_counter = 0; // face index

    std::cout << "Start exploring face" << std::endl;
    // Current indices
    for (const auto &face : faces)
    {
        unsigned f1 = face_counter;

        std::vector<Edges> curr_edges;
        std::cout << "New main face" << face_counter << " " << face << std::endl;

        for (int i = 0; i < 3; i++)
        {
            unsigned f2 = face.neighbor[i];
            unsigned vert0 = face.vertices[(i + 2) % 3];
            unsigned vert1 = face.vertices[(i + 1) % 3];
            if (f2 != static_cast<unsigned>(-1) && f1 != f2)
            {
                Edges e1(vert0, vert1, f1, f2);
                curr_edges.push_back(e1);
            }
        }
        face_counter++;

        for (const auto &edge : curr_edges)
        {

            if (edge_set.find(edge) == edge_set.end())
            {
                if (!isDelaunay(edge))
                {
                    edge_queue.push(edge);
                    edge_set.insert(edge);
                    // std::cout << "This batch candidate edges are " << edge;
                    //  std::cout << " " << faces[edge.f1] << std::endl;
                    //  std::cout << " " << faces[edge.f2] << std::endl;
                }
            }
        }
    }
}

void Mesh::extractEdgesFromFace(std::queue<Edges> &edge_queue, EdgeSet &edge_set, unsigned int &face)
{

    // std::unordered_set<Edges, Edges::Edgeshash> edge_set;
    // std::cout << "Start exploring face" << std::endl;
    unsigned f1 = face;
    // TODO CLea, all add edges
    std::vector<Edges> curr_edges;
    // std::cout << "Edges storing" << std::endl;

    for (int i = 0; i < 3; i++)
    {
        unsigned f2 = faces[face].neighbor[i];
        unsigned vert0 = faces[face].vertices[(i + 2) % 3];
        unsigned vert1 = faces[face].vertices[(i + 1) % 3];
        if (f2 != static_cast<unsigned>(-1) && f1 != f2)
        {
            Edges e1(vert0, vert1, f1, f2);
            if (!edgeCoherence(e1))
            {
                continue;
            }
            curr_edges.push_back(e1);
        }
    }
    // std::cout << "Edges stored" << std::endl;

    for (const auto &edge : curr_edges)
    {

        // std::cout << "Candidate is " << edge << std::endl;
        if (edge_set.find(edge) == edge_set.end())
        {
            if (!isDelaunay(edge))
            {
                std::cout << "Non Delaunay edge" << std::endl;
                std::cout << "Candidate is " << edge << std::endl;
                edge_queue.push(edge);
                edge_set.insert(edge);
            }
        }
    }
}

void Mesh::extractEdgesFromFace(std::queue<Edges> &edge_queue, EdgeSet &edge_set, unsigned int &face, const Faces &back_up)
{

    // EdgeSet edge_set;
    std::cout << "Start exploring face" << std::endl;
    unsigned f1 = face;
    // TODO CLea, all add edges
    std::vector<Edges> curr_edges;
    std::cout << "Edges storing" << std::endl;

    for (int i = 0; i < 3; i++)
    {
        unsigned f2 = back_up.neighbor[i];
        unsigned vert0 = back_up.vertices[(i + 2) % 3];
        unsigned vert1 = back_up.vertices[(i + 1) % 3];
        if (f2 != static_cast<unsigned>(-1) && f1 != f2)
        {
            Edges e1(vert0, vert1, f1, f2);
            if (!edgeCoherence(e1))
            {
                continue;
            }
            curr_edges.push_back(e1);
        }
    }
    std::cout << "Edges stored" << std::endl;

    for (const auto &edge : curr_edges)
    {

        std::cout << "Candidate is " << edge << std::endl;
        if (edge_set.find(edge) == edge_set.end())
        {
            if (!isDelaunay(edge))
            {
                std::cout << "Non Delaunay edge" << std::endl;
                edge_queue.push(edge);
                edge_set.insert(edge);
            }
        }
    }
}
void Mesh::flip_edge(Edges &edge_info)
{
    std::vector<unsigned int> loc_vert_f1;
    std::vector<unsigned int> loc_vert_f2;
    std::vector<unsigned int> edge_faces;
    std::vector<unsigned int> edges_indices;

    Mesh::Circulator_Face itv1 = incident_faces_convex(edge_info.v1);
    int counter_face_search = 0;
    // std::cout << "Get edge incident face" << std::endl;
    //  Get the worrect face
    for (int i = 0; i < itv1.size(); i++, itv1++)
    {
        Mesh::Circulator_Face itv2 = incident_faces_convex(edge_info.v2);

        for (int j = 0; j < itv2.size(); j++, itv2++)
        {
            if (*itv1 == *itv2)
            {
                edge_faces.push_back(*itv1);
                break;
            }
        }
    }

    // On convex hull the circuclator may be unable to go further
    // This wasn't took into account previously
    if (edge_faces.size() < 2)
    {
        std::cout << "Number of faces too low for a flip" << std::endl;
        return;
    };

    unsigned int face1 = edge_faces[0];
    unsigned int face2 = edge_faces[1];

    // counter_create++;
    // std::cout << "ITERATION ITERATION " << counter_create << " ITERATION ITERATION " << std::endl;

    std::cout << "Edge formed with: " << edge_info.v1 << " " << edge_info.v2 << std::endl;

    // std::cout << edge_info.f1 << " " << edge_info.f2 << " " << std::endl;
    // std::cout << edges_faces[0] << " " << edges_faces[1] << " " << edges_faces.size() << std::endl;
    std::cout << "Flip started with Face " << face1 << " " << faces[face1] << std::endl;
    std::cout << "and " << face2 << " " << faces[face2] << std::endl;
    if (!edgeCoherence(edge_info, face1, face2))
    { // TODO stopgap measyre
        std::cout << "The edge was found to be incoherent" << std::endl;
        return;
    }

    // std::string text = "Test_it";
    // std::string result = text + std::to_string(counter_create) + ".obj";
    // write_mesh(result.c_str(), *this, false, false);
    // Our data so far are
    // edges_faces 0 and 1, edge.info v1 and v2

    loc_vert_f1.emplace_back(return_local_indices(faces[face1], edge_info.v1));
    loc_vert_f1.emplace_back(return_local_indices(faces[face1], edge_info.v2));
    loc_vert_f2.emplace_back(return_local_indices(faces[face2], edge_info.v1));
    loc_vert_f2.emplace_back(return_local_indices(faces[face2], edge_info.v2));

    // std::cout << "Flipping start with local vert" << std::endl;
    // std::cout << loc_vert_f1[0] << " " << loc_vert_f1[1] << std::endl;
    // std::cout << loc_vert_f2[0] << " " << loc_vert_f2[1] << std::endl;
    // New face_f1 belong to new edge 2
    // New face_f2 belong to new edge 0
    // V0 here is the vertices at ther right of  an edge
    // For F1, v0 belonged to F2, F
    Faces face1_backup = faces[face1];
    Faces face2_backup = faces[face2];

    // Vertex 1 avec opposé face 10 qui appartenait à 8

    // Sorted in order 4 then 0
    auto opp_vertices = [&](const Edges &e, const Faces &f)
    {
        return f.vertices[return_opposite_vertices(edge_info, f.vertices)]; // opposé à f1
    };

    // Vertice directly opposed to eadch of the other face
    unsigned int new_v0_f1 = opp_vertices(edge_info, faces[face1]); // OK
    unsigned int new_v0_f2 = opp_vertices(edge_info, faces[face2]);

    unsigned int new_v1_f1 = new_v0_f2; // OK
    unsigned int new_v1_f2 = new_v0_f1;

    unsigned int new_v2_f1 = faces[face1].vertices[(return_local_indices(faces[face1], new_v0_f1) + 2) % 3]; // OK
    unsigned int new_v2_f2 = faces[face2].vertices[(return_local_indices(faces[face2], new_v0_f2) + 2) % 3];

    faces[face1].vertices[0] = new_v0_f1;
    faces[face2].vertices[0] = new_v0_f2;

    faces[face1].vertices[1] = new_v1_f1;
    faces[face2].vertices[1] = new_v1_f2;

    faces[face1].vertices[2] = new_v2_f1;
    faces[face2].vertices[2] = new_v2_f2;

    // Last detail important for face move
    //  Update this face neighbor
    //  faces[new_face_v2_f2]
    //  Vertex 1 avec opposé face 10 qui appartenait à 8

    // Change neighboring faces
    // counter_create++;
    // text = "Test_it";
    // result = text + std::to_string(counter_create) + ".obj";
    // write_mesh(result.c_str(), *this, false, false);
    std::cout << "flip finalized with Face " << face1 << " " << faces[face1] << std::endl;
    std::cout << "and " << face2 << " " << faces[face2] << std::endl;
    return;
}

// DELAUNAY SHOULD UPDATE NEIGHBOUR
// DELAUNAY  SHOULD CALCULATE EDGE ITSELF

void lawson(Mesh &mesh)
{
    // Initialize queue
    std::queue<Edges> edge_queue;
    EdgeSet edge_set;

    std::cout << " Extracting edges from   queue " << std::endl;
    mesh.extractEdges(edge_queue);
    // Current indices
    std::cout << edge_queue.size() << " edges in queue " << std::endl;
    while (!edge_queue.empty())
    {

        Edges edge = edge_queue.front();
        edge_queue.pop();

        if (mesh.isDelaunay(edge))
        {
            std::cout << "Delaunay edge " << std::endl;
            std::cout << edge << std::endl;
            continue;
        };

        // Assuming you have a way to find these faces, e.g. using a method to get faces by edge
        // Flip the edge
        mesh.flip_edge(edge);

        // CHECK IF THe other want to be flipped
        // CHECK IF THe other want to be flipped
        // mesh.extractEdgesFromFace(edge_queue,edge_set, edge.f1, mesh.getFace(edge.f1));
        // mesh.extractEdgesFromFace(edge_queue,edge_set, edge.f2, mesh.getFace(edge.f2));
        edge_set.clear();
        // Re-extract edges after flipping
    }
}

#include <algorithm>
std::vector<unsigned int> grahamScan(std::vector<Vertices> &point_cloud, unsigned int &center)
{

    // std::cout << "In scan" << std::endl;
    int n = point_cloud.size();
    if (n < 3)
    {
        std::cout << "Convex Hull need at least 3 points " << std::endl;
        std::vector<unsigned int> ret;
        return ret;
    }

    int sum_x = point_cloud[0].x;
    int sum_y = point_cloud[1].y;

    // trouver le pivot et le conserver à  [0];
    int curr_bottom = 0;
    for (int i = 1; i < n; i++)
    {
        sum_x += point_cloud[i].x;
        sum_y += point_cloud[i].y;
        if (point_cloud[i].y < point_cloud[curr_bottom].y || (point_cloud[i].y == point_cloud[curr_bottom].y && point_cloud[i].x < point_cloud[curr_bottom].x))
        {
            curr_bottom = i;
        }
    }
    // std::cout << "bottom is " << point_cloud[curr_bottom] << std::endl;
    // std::cout << "nb is " << point_cloud.size() << std::endl;

    // Approximate the centroid
    Vertices centroid(sum_x / n, sum_y / n, 0.0);
    // std::cout<<"fisrt is "<< point_cloud[0];
    std::swap(point_cloud[curr_bottom], point_cloud[0]);
    // std::cout<<" and now  is "<< point_cloud[0] << std::endl;

    // Tri par ordre polaire par rapport au pivot
    std::sort(point_cloud.begin() + 1, point_cloud.end(), [&point_cloud](const Vertices &vert1, const Vertices &vert2)
              {
        int orientation = orientation_test_2d(point_cloud[0],vert1, vert2);
        if (orientation == 0){return (point_cloud[0].x - vert1.x) * (point_cloud[0].x - vert1.x) + (point_cloud[0].y - vert1.y) * (point_cloud[0].y - vert1.y) < 
                   (point_cloud[0].x - vert2.x) * (point_cloud[0].x - vert2.x) + (point_cloud[0].y - vert2.y) * (point_cloud[0].y - vert2.y);
                           //return (vert1.x < vert2.x) || (vert1.x ==vert2.x && vert1.y < vert2.y);
                           }else{
        return (orientation < 0);} });

    // Mettre les premiers points dans une pile
    std::vector<Vertices> hull_stack;
    hull_stack.push_back(point_cloud[0]);
    hull_stack.push_back(point_cloud[1]);
    std::vector<unsigned int> hull_stack_indices;
    hull_stack_indices.emplace_back(0);
    hull_stack_indices.emplace_back(1);

    double min_dist = std::numeric_limits<double>::max();
    // Step 4: Process remaining points
    unsigned int nearest = 0;
    for (int i = 2; i < n; i++)
    {
        // TODO rvoirr tout ça
        while (hull_stack.size() > 1 && orientation_test_2d(hull_stack[hull_stack.size() - 2], hull_stack.back(), point_cloud[i]) > 0)
        {
            hull_stack.pop_back();
            hull_stack_indices.pop_back();
        }
        hull_stack.push_back(point_cloud[i]); // Add the current point
        hull_stack_indices.emplace_back(i);

        // Also treating the centroid
        double distance = std::sqrt(std::pow(point_cloud[i].x - centroid.x, 2) + pow(point_cloud[i].y - centroid.y, 2));
        if (distance < min_dist)
        {
            min_dist = distance;
            nearest = i;
        }
    }
    center = nearest;
    // std::cout << "nb is hull  " << hull_stack_indices.size() << std::endl;

    return hull_stack_indices; // Return pairs of indices in the hull
}

std::vector<unsigned int> generateUniqueRandomNumbers(int size, std::vector<unsigned> &exclusions)
{
    // Create a vector with all numbers in the range
    std::vector<unsigned int> numbers;
    for (int i = 0; i < size; ++i)
    {
        numbers.push_back(i);
    }
    for (unsigned int excl : exclusions)
    {
        numbers.erase(std::remove(numbers.begin(), numbers.end(), excl), numbers.end());
    }
    // Shuffle the vector
    std::random_device rd;
    std::mt19937 gen(rd());
    std::shuffle(numbers.begin(), numbers.end(), gen);

    return numbers;
}

void Mesh::incremental_triangulate2(Mesh &mesh)
{
    // Create a face 0 with the three first point
    if (mesh.getFacesNb() > 0 || mesh.getVerticesNb() == 0)
    {
        std::cout << "Triangulation must be done right after creation of the point cloud" << std::endl;
        return;
    };

    // Create Convex Hull through graham scan
    std::cout << "Creating convex hull" << std::endl;
    // The point the closest of the centroid we could find
    unsigned int center = 0;
    convex_hull = grahamScan(vertices, center);

    if (convex_hull.size() == mesh.vertices.size())
    {
        return;
    };
    for (int i = 0; i < convex_hull.size(); i++)
    {
        std::cout << "Convexhull member " << convex_hull[i] << " " << vertices[convex_hull[i]] << std::endl;
    }

    // Control of the convex hull here
    // First insertion
    size_t convex_hull_size = convex_hull.size();
    for (int i = 0; i < convex_hull_size; i++)
    {
        mesh.swapVerticeFace(convex_hull[i]) = makeFace(center, convex_hull[i % (convex_hull_size)], convex_hull[(i + 1) % (convex_hull_size)]);
    }
    for (int i = 0; i < convex_hull_size; i++)
    {
        faces[i].neighbor[2] = ((i - 1) + convex_hull_size) % convex_hull_size;
        faces[i].neighbor[1] = (i + 1) % convex_hull_size;
    }

    lawson(*this);
    // For this step, we won't need to consider the insertion outside the convex hull at all
    int counter = 0;
    int size = vertices.size();
    std::vector<unsigned int> pre_inserted(convex_hull);
    std::cout << "Center is " << center << " " << vertices[center] << std::endl
              << std::endl;
    pre_inserted.push_back(center);
    // Should sort again to get back the correct point of the convex hull
    std::queue<Edges> edge_queue;
    EdgeSet edge_set;

    std::vector<unsigned int> traversal = generateUniqueRandomNumbers(size, pre_inserted);
    while (counter < traversal.size())
    {
        bool skip = 0;
        for (int i = 0; i < pre_inserted.size(); i++)
        {
            if (counter == pre_inserted[i])
            {
                skip = 1;
            }
        }
        if (skip == 0)
        {
            std::cout << "Inserting point number " << traversal[counter] << " " << vertices[traversal[counter]] << std::endl;
            unsigned face;

            // Pre extract "border-edge"
            Faces face_backup = mesh.insert_point_convexless(counter, face);

            std::cout << face << std::endl;
            std::cout << face_backup << std::endl;
            unsigned face2 = faces.size() - 1;
            unsigned face3 = faces.size() - 2;

            extractEdgesFromFace(edge_queue, edge_set, face, face_backup);
            // extractEdgesFromFace(edge_queue, face3);
            // extractEdgesFromFace(edge_queue, face2);

            while (!edge_queue.empty())
            {
                Edges current_edge = edge_queue.front();
                std::cout << current_edge << std::endl;

                edge_queue.pop();
                if (!isDelaunay(current_edge))
                {
                    flip_edge(current_edge);
                }
            }
            std::cout << "Inserted point " << traversal[counter] << std::endl
                      << std::endl;
            edge_set.clear();
        }
        counter++;
    }
};

void Mesh::incremental_triangulate(Mesh &mesh)
{
    // Create a face 0 with the three first point
    if (mesh.getFacesNb() > 0 || mesh.getVerticesNb() == 0)
    {
        std::cout << "Triangulation must be done right after creation of the point cloud" << std::endl;
        return;
    };

    // Create Convex Hull through graham scan
    std::cout << "Creating convex hull" << std::endl;
    // The point the closest of the centroid we could find
    unsigned int center = 0;
    convex_hull = grahamScan(vertices, center);

    if (convex_hull.size() == mesh.vertices.size())
    {
        return;
    };

    // Control of the convex hull here
    // First insertion
    size_t convex_hull_size = convex_hull.size();
    for (int i = 0; i < convex_hull_size; i++)
    {
        mesh.swapVerticeFace(convex_hull[i]) = makeFace(center, convex_hull[i % (convex_hull_size)], convex_hull[(i + 1) % (convex_hull_size)]);
    }
    for (int i = 0; i < convex_hull_size; i++)
    {
        faces[i].neighbor[2] = ((i - 1) + convex_hull_size) % convex_hull_size;
        faces[i].neighbor[1] = (i + 1) % convex_hull_size;
    }

    lawson(*this);
    // For this step, we won't need to consider the insertion outside the convex hull at all
    int counter = 0;
    int size = vertices.size();
    std::vector<unsigned int> pre_inserted(convex_hull);
    std::cout << "Center is " << center << " " << vertices[center] << std::endl
              << std::endl;
    pre_inserted.push_back(center);
    // Should sort again to get back the correct point of the convex hull
    std::queue<Edges> edge_queue;
    EdgeSet edge_set;

    std::vector<unsigned int> traversal = generateUniqueRandomNumbers(size, pre_inserted);
    while (counter < traversal.size())
    {
        bool skip = 0;
        for (int i = 0; i < pre_inserted.size(); i++)
        {
            if (counter == pre_inserted[i])
            {
                skip = 1;
            }
        }
        if (skip == 0)
        {
            std::cout << "Inserting point number " << traversal[counter] << " " << vertices[traversal[counter]] << std::endl;
            unsigned face;

            // Pre extract "border-edge"
            Faces face_backup = mesh.insert_point_convexless(counter, face);

            std::cout << face << std::endl;
            std::cout << face_backup << std::endl;
            unsigned face2 = faces.size() - 1;
            unsigned face3 = faces.size() - 2;

            extractEdgesFromFace(edge_queue, edge_set, face, face_backup);
            // extractEdgesFromFace(edge_queue, face3);
            // extractEdgesFromFace(edge_queue, face2);

            while (!edge_queue.empty())
            {
                Edges current_edge = edge_queue.front();
                std::cout << current_edge << std::endl;

                edge_queue.pop();
                if (!isDelaunay(current_edge))
                {
                    flip_edge(current_edge);
                }
            }
            std::cout << "Inserted point " << traversal[counter] << std::endl
                      << std::endl;
            edge_set.clear();
        }
        counter++;
    }
};

Faces Mesh::insert_point_convexless(const unsigned int &new_point, unsigned int &vertices_face)
{
    // Identify if this point belong to a face
    std::cout << "Identifying " << new_point << std::endl;
    vertices_face = identify_point_face(vertices[new_point]);
    Faces back_up = faces[vertices_face];
    std::cout << "The face of this point is " << vertices_face << std::endl;
    if (static_cast<unsigned int>(-1) == vertices_face)
    {
        std::cout << "The face of this point is " << vertices_face << ", an edge will be added :" << std::endl
                  << std::endl;
        std::exit(EXIT_FAILURE);
    }
    else
    {
        // counter_create++;
        // std::string text = "Test_it";
        // std::string result = text + std::to_string(counter_create) + ".obj";
        // write_mesh(result.c_str(), *this, false, false);
        // std::cout << "Iteration " << counter_create << std::endl;

        split_triangle(new_point, vertices_face);
        // counter_create++;
        // text = "Test_it";
        // result = text + std::to_string(counter_create) + ".obj";
        // write_mesh(result.c_str(), *this, false, false);
    }
    return back_up;
}

void Mesh::split_triangle(unsigned int new_vert_index, unsigned int &new_vertices_face)
{
    // If the insertion face is not know, we start identifying it
    // std::cout << "Splitting " << faces[new_vertices_face] << std::endl;
    // std::cout << "Vertice inserterd is  " << new_vert_index << " with " << faces[new_vertices_face].vertices[0] << " " << faces[new_vertices_face].vertices[1] << " " << faces[new_vertices_face].vertices[2] << "with " << vertices.back() << std::endl;

    // Init
    Faces back_up = faces[new_vertices_face];
    unsigned vert1 = faces[new_vertices_face].vertices[0];
    unsigned vert2 = faces[new_vertices_face].vertices[1];
    unsigned vert3 = faces[new_vertices_face].vertices[2];
    // std::cout << "Vertice involved are  " << vert1 << " with " << vert2 << " " << vert3 << " " << new_vert_index << std::endl;

    // Push three new faces and set up their fae
    // Maintained face is the one with vert1, vert2

    faces[new_vertices_face].vertices[2] = new_vert_index;
    faces.emplace_back(new_vert_index, vert2, vert3, faces[new_vertices_face]);
    faces.emplace_back(vert1, new_vert_index, vert3, faces[new_vertices_face]);
    // Maintained face is also the opposite of edge vert[2]
    faces[new_vertices_face].neighbor[0] = faces.size() - 2;
    faces[new_vertices_face].neighbor[1] = faces.size() - 1;

    // For other faces, faces at same indices as new_vert_index is untouched for now
    faces[faces.size() - 2].neighbor[1] = faces.size() - 1;
    faces[faces.size() - 2].neighbor[2] = new_vertices_face;
    faces[faces.size() - 1].neighbor[0] = faces.size() - 2;
    faces[faces.size() - 1].neighbor[2] = new_vertices_face;

    // Necessary for easy circulation
    // Update vert3 as thetr is a chance it see itself as incident to "new_vertices_face"
    vertices[vert3].face = faces.size() - 2;
    vertices[vert2].face = faces.size() - 2;
    vertices[vert1].face = faces.size() - 1;
    vertices[new_vert_index].face = new_vertices_face;

    // May require more care
    //  faces[faces.size() - 2].neighbor[0] = back_up.neighbor[0];
    // faces[faces.size() - 1].neighbor[1] = back_up.neighbor[1];
    // At last for each of tthe neighboring oppostite to the added vertices

    if (faces[faces.size() - 2].neighbor[0] == new_vertices_face)
    {
        // faces[faces.size() - 2].neighbor[0] = static_cast<unsigned int>(-1);
        faces[faces.size() - 2].neighbor[0] = faces.size() - 2;
    }
    else
    { // Handle neighbor triangle
        Faces &neighbor = faces[faces[faces.size() - 2].neighbor[0]];
        for (int i = 0; i < neighbor.neighbor.size(); i++)
        {
            if (neighbor.neighbor[i] == new_vertices_face)
            {
                neighbor.neighbor[i] = faces.size() - 2;
                break;
            }
        }
    }
    if (faces[faces.size() - 1].neighbor[1] == new_vertices_face)
    {
        // faces[faces.size() - 1].neighbor[1] = static_cast<unsigned int>(-1);
        faces[faces.size() - 1].neighbor[1] = faces.size() - 1;
    }
    else
    { // Handle neighbor triangle
        Faces &neighbor = faces[faces[faces.size() - 1].neighbor[1]];
        for (int i = 0; i < neighbor.neighbor.size(); i++)
        {
            if (neighbor.neighbor[i] == new_vertices_face)
            {
                neighbor.neighbor[i] = faces.size() - 1;
                break;
            }
        }
    }

    std::cout << "This face gaves us post spliting " << std::endl;
    std::cout << faces.size() - 2 << " " << faces[faces.size() - 2] << std::endl;
    std::cout << faces.size() - 1 << " " << faces[faces.size() - 1] << std::endl;
    std::cout << new_vertices_face << " " << faces[new_vertices_face] << std::endl;
}

bool Mesh::isDelaunay(edges edge, unsigned int shared_face_indx)
{

    // Cercle circonscrit des triangle incluant
    Faces shared_face = faces[shared_face_indx];
    unsigned third_vertice_loc = 0;
    unsigned third_vertice = 0;

    // Valeur de la face partagée
    for (int i = 0; i < shared_face.vertices.size(); i++)
    {
        if (shared_face.vertices[0] != edge.first && shared_face.vertices[0] != edge.second)
        {
            third_vertice = shared_face.vertices[i];
            third_vertice_loc = i;
        }
    }

    unsigned fourth_vertice = 0;
    unsigned opposite_face = shared_face.neighbor[third_vertice_loc];

    for (int i = 0; i < faces[opposite_face].vertices.size(); i++)
    {
        if (faces[opposite_face].vertices[0] != edge.first && faces[opposite_face].vertices[0] != edge.second)
        {
            fourth_vertice = faces[opposite_face].vertices[i];
        }
    }

    auto determinant = [](double a11, double a12, double a13,
                          double a21, double a22, double a23,
                          double a31, double a32, double a33)
    {
        return a11 * (a22 * a33 - a23 * a32) -
               a12 * (a21 * a33 - a23 * a31) +
               a13 * (a21 * a32 - a22 * a31);
    };

    double a11 = vertices[edge.first].x - vertices[fourth_vertice].x;
    double a21 = vertices[edge.second].x - vertices[fourth_vertice].x;
    double a31 = vertices[third_vertice].x - vertices[fourth_vertice].x;
    double a12 = vertices[edge.first].y - vertices[fourth_vertice].y;
    double a22 = vertices[edge.second].y - vertices[fourth_vertice].y;
    double a32 = vertices[third_vertice].y - vertices[fourth_vertice].y;

    double det = determinant(a11, a12, (a11)*a11 + a12 * a12,
                             a21, a22, (a21)*a21 + a22 * a22,
                             a31, a32, (a31)*a31 + a32 * a32);
    // if counter clockwise
    bool triangle_counterclock = ((orientation_test_2d(vertices[edge.first], vertices[edge.second],
                                                       vertices[third_vertice])) > 0);
    if (triangle_counterclock)
    {
        if (det >= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        if (det >= 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    return false;

    /*
   // Compute the vector of the face
   Vertices vector_c_a = vertices[edge.first] - vertices[third_vertice];
   Vertices vector_c_b = vertices[edge.second] - vertices[third_vertice];

   Vertices vector_b_c = vertices[edge.first] - vertices[edge.second];
   Vertices vector_b_a = vertices[third_vertice] - vertices[edge.second];

   Vertices vector_a_c = vertices[third_vertice] - vertices[edge.first];
   Vertices vector_a_b = vertices[edge.second] - vertices[edge.first];

   auto tan = [](const Vertices &a, const Vertices &b)
   {
       double tang;
       double cos = dotProduct(a, b) / (magn(a) * magn(b));
       if(cos == 0){return 0.0;}
       double sin = magn(crossProduct(a, b)) / (magn(a) * magn(b));
       tang= sin *(1/cos);
       return tang;
       /*

       Vertices crssprodc = crossProduct(a,b);
       return dotProduct(crssprodc,Vertices(0,0,1))*magn(crssprodc)/dotProduct(a,b); */
    /*
   //Compute the tang value
   float tanA = tan(vector_a_c,vector_a_b);
   float tanB= tan(vector_b_c,vector_b_a);
   float tanC= tan(vector_c_b,vector_c_a);
   Vertices H =  Vertices(tanB+tanC,tanC+tanA,tanA+tanB);
   //Dealing with the second triangle
   unsigned opposite_face = shared_face.neighbor[third_vertice_loc];
   if(opposite_face == shared_face_indx){//NO other triangle on this side

   }
   */
};

bool Mesh::edgeCoherence(Edges edge)
{
    bool resultf1v2 = false;
    bool resultf2v1 = false;
    bool resultf1v1 = false;
    bool resultf2v2 = false;

    for (int i = 0; i < 3; i++)
    {
        if (faces[edge.f1].vertices[i] == edge.v1)
        {
            resultf1v1 = true;
        }
        if (faces[edge.f1].vertices[i] == edge.v2)
        {
            resultf1v2 = true;
        }
        if (faces[edge.f2].vertices[i] == edge.v1)
        {
            resultf2v1 = true;
        }
        if (faces[edge.f2].vertices[i] == edge.v2)
        {
            resultf2v2 = true;
        }
    }
    return resultf1v1 & resultf1v2 & resultf2v1 & resultf2v2;
}

bool Mesh::edgeCoherence(Edges edge, unsigned int face1, unsigned int face2)
{
    bool resultf1v2 = false;
    bool resultf2v1 = false;
    bool resultf1v1 = false;
    bool resultf2v2 = false;
    for (int i = 0; i < 3; i++)
    {
        if (faces[face1].vertices[i] == edge.v1)
        {
            resultf1v1 = true;
        }
        if (faces[face1].vertices[i] == edge.v2)
        {
            resultf1v2 = true;
        }
        if (faces[face2].vertices[i] == edge.v1)
        {
            resultf2v1 = true;
        }
        if (faces[face2].vertices[i] == edge.v2)
        {
            resultf2v2 = true;
        }
    }
    return resultf1v1 & resultf1v2 & resultf2v1 & resultf2v2;
}

Vertices compute_circum_cirle(const Vertices &vert1, const Vertices &vert2, const Vertices &vert3)
{
    auto tan = [&](const Vertices &A, const Vertices &B, const Vertices &C)
    {
        Vertices crss = crossProduct(C - B, A - B);
        int sign = dotProduct(crss, Vertices(0, 0, 1));
        if (sign > 0)
        {
            sign = 1;
        }
        else if (sign < 0)
        {
            sign = -1;
        }
        else if (sign == 0)
        {
            sign = 0;
        }
        return sign * magn(crss) / dotProduct(C - B, A - B);
    };

    float tan_a = tan(vert1, vert2, vert3);
    float tan_b = tan(vert2, vert3, vert1);
    float tan_c = tan(vert3, vert1, vert2);
    float tan_sum = tan_a + tan_b + tan_c;

    // return Vertices((tan_b + tan_c)/tan_sum, (tan_c + tan_a)/tan_sum, (tan_a + tan_b)/tan_sum);
    return (vert2 * (tan_b + tan_c) + vert3 * (tan_c + tan_a) + vert2 * (tan_a + tan_b)) / tan_sum;
    ///////////////////////////////////
}

Vertices compute_circumcenter(const Vertices &vert1, const Vertices &vert2, const Vertices &vert3)
{
    auto det = [&](const Vertices &A, const Vertices &B, const Vertices &C)
    {
        double D = 2 * (A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y));

        if (D == 0)
        {
            return Vertices(0, 0, 0);
        }

        double Ux = ((A.x * A.x + A.y * A.y) * (B.y - C.y) +
                     (B.x * B.x + B.y * B.y) * (C.y - A.y) +
                     (C.x * C.x + C.y * C.y) * (A.y - B.y)) /
                    D;

        double Uy = ((A.x * A.x + A.y * A.y) * (C.x - B.x) +
                     (B.x * B.x + B.y * B.y) * (A.x - C.x) +
                     (C.x * C.x + C.y * C.y) * (B.x - A.x)) /
                    D;
        return Vertices(Ux, Uy, 0);
    };

    return det(vert1, vert2, vert3);
}

bool isInsideCircumcircle(const Vertices &vert1, const Vertices &vert2, const Vertices &vert3, const Vertices &vert4)
{

    /*if (orientation_test_2d(vert1, vert2, vert3) < 0)
    {
        return isInsideCircumcircle(vert3, vert2, vert1, vert4);
    }*/
    Vertices center = compute_circumcenter(vert1, vert2, vert3);

    double radius_squared = (center.x - vert1.x) * (center.x - vert1.x) +
                            (center.y - vert1.y) * (center.y - vert1.y);
    double distance_squared = (center.x - vert4.x) * (center.x - vert4.x) +
                              (center.y - vert4.y) * (center.y - vert4.y); // Squared distance

    if (distance_squared < radius_squared)
    {
        return true;
    }
    else
    {
        return false;
    };
}

// https://en.wikipedia.org/wiki/Delaunay_triangulation
inline float circumcircleDeterminant(const Vertices &A, const Vertices &B, const Vertices &C, const Vertices &D)
{
    return A.x * (B.y * (C.x * C.x + C.y * C.y) - C.y * (B.x * B.x + B.y * B.y) + D.y * (B.x * B.x + B.y * B.y - C.x * C.x - C.y * C.y)) -
           B.x * (A.y * (C.x * C.x + C.y * C.y) - C.y * (A.x * A.x + A.y * A.y) + D.y * (A.x * A.x + A.y * A.y - C.x * C.x - C.y * C.y)) + C.x * (A.y * (B.x * B.x + B.y * B.y) - B.y * (A.x * A.x + A.y * A.y) + D.y * (A.x * A.x + A.y * A.y - B.x * B.x - B.y * B.y)) + D.x * (A.y * (B.x * B.y - C.x * C.y) + B.y * (C.x * C.x + C.y * C.y - A.x * A.x - A.y * A.y) - C.y * (A.x * A.x + A.y * A.y - B.x * B.x - B.y * B.y));
}

// Function to calculate the sign of a determinant
double SignDeterminant(double a, double b, double c,
                       double d, double e, double f,
                       double g, double h, double i)
{
    return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
}

// Function to determine if point s is inside the circle circumscribed by points p, q, r
bool isInsideCircumcircle3(const Vertices &p, const Vertices &q, const Vertices &r, const Vertices &s)
{
    // Calculate the terms for the determinant
    // Possiblement pas utile
    if (orientation_test_2d(p, q, r) > 0)
    {
        std::cout << "pqr orientaiton was BADBABDBAD" << std::endl;
        return isInsideCircumcircle3(r, q, p, s);
    };
    double qpx = q.x - p.x;
    double qpy = q.y - p.y;
    double rpx = r.x - p.x;
    double rpy = r.y - p.y;
    double spx = s.x - p.x;
    double spy = s.y - p.y;

    double q_dist_squared = qpx * qpx + qpy * qpy;
    double r_dist_squared = rpx * rpx + rpy * rpy;
    double s_dist_squared = spx * spx + spy * spy;

    double determinant = SignDeterminant(
        qpx, rpx, spx,
        qpy, rpy, spy,
        q_dist_squared, r_dist_squared, s_dist_squared);
    //(-determinant > 0) This had better result
    return (-determinant < 0); // If true it is inside
}

bool Mesh::isDelaunay(Edges edge)
{

    std::vector<unsigned int> edge_faces;

    Mesh::Circulator_Face itv1 = incident_faces_convex(edge.v1);
    int counter_face_search = 0;
    std::cout << "In Delaunay check" << std::endl;
    std::cout << edge << std::endl;

    // Get the worrect face
    for (int i = 0; i < itv1.size(); i++, itv1++)
    {
        Mesh::Circulator_Face itv2 = incident_faces_convex(edge.v2);
        for (int j = 0; j < itv2.size(); j++, itv2++)
        {
            if (*itv1 == *itv2)
            {
                edge_faces.push_back(*itv1);
                break;
            }
        }
    }

    // On convex hull the circuclator may be unable to go further
    // This wasn't took into account previously
    if (edge_faces.size() < 2)
    {
        std::cout << "Early exit for invalid face" << std::endl;
        // May result from previous flip
        return true;
    };
    // Cercle circonscrit des triangle incluant
    // Faces shared_face = faces[edge.f1];
    Faces shared_face = faces[edge_faces[0]];
    Faces opposite_face = faces[edge_faces[1]];
    unsigned third_vertice = shared_face.vertices[return_opposite_vertices(edge, shared_face.vertices)];
    unsigned fourth_vertice = opposite_face.vertices[return_opposite_vertices(edge, opposite_face.vertices)];
    /*std::cout << edge_faces[0]<<std::endl;
    std::cout << edge_faces[1]<<std::endl;
    std::cout<<shared_face << std::endl;
    std::cout<<opposite_face << std::endl;



    std::cout<<"The icnidce that are obviously local" <<std::endl;
    std::cout<<"The icnidce that are obviously local" <<std::endl;
        std::cout<<third_vertice << std::endl;
    std::cout<<fourth_vertice << std::endl;

    std::cout<< vertices[edge.v1] << std::endl;
    std::cout<< vertices[edge.v2] << std::endl;
    std::cout<<  vertices[third_vertice] << std::endl;
    std::cout<< vertices[fourth_vertice] << std::endl;*/
    if (isInsideCircumcircle3(vertices[edge.v1], vertices[edge.v2], vertices[third_vertice], vertices[fourth_vertice]))
    {
        return false;
    }
    if (isInsideCircumcircle3(vertices[edge.v1], vertices[edge.v2], vertices[fourth_vertice], vertices[third_vertice]))
    {
        return false;
    }

    return true;
}

Mesh boywerwatson(std::vector<Vertices> &vertices)
{
    // We choose  not to use the mesh structure for simplicity
    // Look for the min and max
    float max_x = std::numeric_limits<float>::min();
    float max_y = std::numeric_limits<float>::min();
    float min_x = std::numeric_limits<float>::max();
    float min_y = std::numeric_limits<float>::max();
    for (const auto &vertex : vertices)
    {
        if (vertex.x > max_x)
            max_x = vertex.x;
        if (vertex.y > max_y)
            max_y = vertex.y;
        if (vertex.x < min_x)
            min_x = vertex.x;
        if (vertex.y < min_y)
            min_y = vertex.y;
    }

    // List of faces containing the super triangle
    std::vector<Faces> faces;
    float margin = 20.0f;
    vertices.emplace_back((max_x + min_x) / 2 + margin, max_y + margin, 0.0);
    vertices.emplace_back(min_x - margin, min_y - margin, 0.0);
    vertices.emplace_back(max_x + margin, min_y - margin, 0.0);
    // Super triangle addition
    faces.emplace_back(vertices.size() - 3, vertices.size() - 2, vertices.size() - 1);
    // First faces is the super triangle face.
    //  Main loop
    std::cout << faces[0] << std::endl;

    int vertex_count = 0;
    int facecounter = 0;
    // Every verticees entry point into the triangulation
    for (int i = 0; i < vertices.size() - 3; ++i)
    {
        std::cout << "New point" << std::endl;
        // For each iteration adding new point, the face to remove.
        std::vector<Faces> invalid_faces;
        std::vector<Edges> edges_vec;
        std::unordered_map<Edges, int, Edges::Edgeshash> edge_count;

        // std::cout << faces.size() << std::endl;
        // Get Bad triangle
        for (auto &face : faces)
        {
            if (isInsideCircumcircle(vertices[face.vertices[0]],
                                     vertices[face.vertices[1]],
                                     vertices[face.vertices[2]], vertices[i]))
            { // Insert edges not tied to more than two bad triangle
                invalid_faces.push_back(face);
                for (int e = 0; e < 3; e++)
                {
                    Edges edge(face.vertices[e], face.vertices[(e + 1) % 3]);
                    edge_count[edge]++;
                }
            }
        }

        // Remove invaldi faces
        for (auto &face_to_remove : invalid_faces)
        {
            faces.erase(std::remove_if(faces.begin(), faces.end(),
                                       [&face_to_remove](const Faces &f)
                                       { return f == face_to_remove; }),
                        faces.end());
        }

        // Remove duplicate edges (polygon boundary edge)
        for (const auto &edge : edge_count)
        {
            if (edge.second == 1)
            {
                edges_vec.push_back(edge.first);
            }
        }

        // std::cout << edges_vec.size() << std::endl;
        // std::cout << faces.size() << std::endl;

        // Remove duplicate edge

        for (const auto &edges : edges_vec)
        {
            if (orientation_test_2d(vertices[edges.v1], vertices[edges.v2], vertices[i]) > 0)
            {
                Faces f = Faces(edges.v1, edges.v2, i);
                // std::cout << f << std::endl;
                faces.push_back(f);
            }
            else
            {
                Faces f = Faces(i, edges.v2, edges.v1);
                // std::cout << f << std::endl;

                faces.push_back(f);
            }
        }
        vertex_count++;
    }
    std::cout << "All point" << std::endl;

    // std::cout << faces[0] << std::endl;
    faces.erase(std::remove_if(faces.begin(), faces.end(),
                               [&](const Faces &face)
                               {
                                   return (return_local_indices(face, vertices.size() - 1) != 3) ||
                                          (return_local_indices(face, vertices.size() - 3) != 3) ||
                                          (return_local_indices(face, vertices.size() - 2) != 3);
                               }),
                faces.end());
    return Mesh(vertices, faces);
}
int main(int argc, const char *argv[])
{

    // Define a default filename
    const char *default_cloud_point = "alpes_poisson.txt";
    const char *points_arg = default_cloud_point;
    if (argc > 1)
    {
        points_arg = argv[1]; // Override with the command-line argument if provided
    }
    std::vector<Vertices> vertices_tab;
    vertices_tab = load_mesh2d_point(points_arg, 1);
    Mesh titi(vertices_tab);
    titi.incremental_triangulate2(titi);
    lawson(titi);
    write_mesh("NotDelaunay.obj", titi, false, false);
}