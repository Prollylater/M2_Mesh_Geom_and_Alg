#pragma once
// TODO EVERY i+1%3 to 2
#include <fstream>
#include <iostream>
#include <random>
#include <iomanip>
#include <sstream>
#include <cassert>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <functional>
#include <cmath>
#include "Vertices.hpp"

// Pre_allocated efault Variables
constexpr float common_time_step = 0.05;
struct Faces;
struct Mesh;

#include <queue>
#include <set>
struct Edges
{

    unsigned v1, v2;
    unsigned f1, f2;
    Edges(const unsigned &vc1, const unsigned &vc2, const unsigned &fc1, const unsigned &fc2)
    {
        bool vertex = vc1 > vc2;
        bool face = fc1 > fc2;
        v1 = vertex ? vc1 : vc2;
        v2 = vertex ? vc2 : vc1;
        f1 = face ? fc1 : fc2;
        f2 = face ? fc2 : fc1;
    }

    Edges(const unsigned &vc1, const unsigned &vc2) : f1(0), f2(0)
    {
        bool vertex = vc1 > vc2;
        v1 = vertex ? vc1 : vc2;
        v2 = vertex ? vc2 : vc1;
    }

    friend std::ostream &operator<<(std::ostream &os, const Edges &edge_info)
    {
        os << "Edges: " << edge_info.v1
           << " " << edge_info.v2 << " Face: " << edge_info.f1
           << "  " << edge_info.f2 << std::endl;
        return os;
    }

    bool operator==(const Edges &rhs) const
    {
        return (v1 == rhs.v1 && v2 == rhs.v2) || (v1 == rhs.v2 && v1 == rhs.v2);
    };
    bool operator!=(const Edges &rhs) const
    {
        return !(*this == rhs);
    }

    struct Edgeshash
    {
        std::size_t operator()(const Edges &edge) const
        {
            return (std::hash<unsigned int>()(edge.v1) +
                    (std::hash<unsigned int>()(edge.v2) << 1));
        }
    };
};
typedef std::unordered_set<Edges, Edges::Edgeshash> EdgeSet;

// positive = orientend clockwise

using edges = std::pair<unsigned, unsigned>;
using edges_face = std::pair<unsigned, unsigned>;
float orientation_test_2d(const Vertices &vert1,
                          const Vertices &vert2, const Vertices &vert3);
/*
int orientation_test_2d(const Mesh &mesh, const unsigned int &face)
{
    unsigned vert0 = (mesh.getFace(face)).vertices[0];
    unsigned vert1 = (mesh.getFace(face)).vertices[1];
    unsigned vert2 = (mesh.getFace(face)).vertices[2];
}
*/
float in_triangle_test_2d(const Mesh &mesh, const unsigned int &face, const Vertices &point);
// FACE STRUCT
////////////////////////////////////////////////////////////////
struct Faces
{
    std::vector<unsigned> vertices; // Indices à utilisable uniquement par la classe Mesh
    std::vector<unsigned> neighbor; // Indices des faces voisines
    // Cosntructor
    Faces() = default;
    Faces(unsigned x, unsigned y, unsigned z) : vertices{x, y, z}, neighbor(3) {};
    Faces(unsigned x, unsigned y, unsigned z, const Faces &face) : vertices{x, y, z}, neighbor(face.neighbor) {

                                                                   };
    Faces(const Faces &face) : vertices(face.vertices), neighbor(face.neighbor) {};

    bool operator==(const Faces &rhs) const { return (vertices == rhs.vertices) && (neighbor == rhs.neighbor); };

    bool operator!=(const Faces &rhs) const
    {
        return !(*this == rhs);
    }

    friend std::ostream &operator<<(std::ostream &os, const Faces &face)
    {
        os << "Vertices: " << face.vertices[0]
           << "  " << face.vertices[1]
           << " " << face.vertices[2] << " Neighbor: " << face.neighbor[0]
           << "  " << face.neighbor[1]
           << " " << face.neighbor[2] << std::endl;
        return os;
    }

    ~Faces() = default;
};

// Retourne l'indice local de sommet
inline unsigned return_local_indices(const Faces &face, unsigned glob_indices)
{
    unsigned i = 0;
    for (const auto &vert : face.vertices)
    {
        if (vert != glob_indices)
        {
            i++;
            continue;
        }
        else
        {
            break;
        }
    }
    return i;
}

// MESH
class Mesh;

// Some function make more sense in Mesh
std::vector<unsigned> travel(const Mesh &mesh, unsigned vertices_indices);
unsigned getNeighbors(const Faces &curr_face, unsigned &indice, std::function<unsigned(const unsigned &)> direction);
inline unsigned return_local_indices(const Faces &face, unsigned glob_indices);

class Mesh
{
private:
    std::vector<Vertices> vertices;
    std::vector<Faces> faces; // Itself imply infinite face
    // std::vector<edgesConvex> convex_hull; // Indices of faces tied to infinite triangle
    // std::vector<Vertices> convex_hull; // Indices of faces tied to infinite triangle
    std::vector<unsigned int> convex_hull;

public:
    Mesh() = default;
    Mesh(const std::vector<Vertices> &p_vertices) : vertices(p_vertices) {};
    Mesh(const std::vector<Vertices> &p_vertices, const std::vector<Faces> &p_faces) : vertices(p_vertices), faces(p_faces) {};
    Mesh(std::vector<Vertices> &&p_vertices, const std::vector<Faces> &&p_faces) : vertices(std::move(p_vertices)), faces(std::move(p_faces)) {};

    Vertices getVertice(unsigned indice) const
    {
        return vertices[indice];
    }
    unsigned int &swapVerticeFace(unsigned indice)
    {
        return vertices[indice].face;
    }

    Faces getFace(unsigned indice) const
    {
        return faces[indice];
    }
    int getVerticesNb() const
    {
        return vertices.size();
    }

    int getFacesNb() const
    {
        return faces.size();
    }

    int addVertice(const Vertices &vert)
    {
        vertices.emplace_back(vert.x, vert.y, vert.z);
        return vertices.size() - 1;
    }

    int makeFace(int index1, int index2, int index3)
    {
        faces.emplace_back(index1, index2, index3);
        int size = faces.size() - 1;
        faces[size].neighbor.resize(3);
        std::fill(faces[size].neighbor.begin(), faces[size].neighbor.end(), size);
        return faces.size() - 1;
    }

    // Return a neighbor in direction specified by a function of type indice_local + (1 or 2)/3
    unsigned int getNeighborInFace(unsigned &indice_face, unsigned &indice_vertex, std::function<unsigned(const unsigned &)> direction)
    {
        // Return the face opposed to local indices
        return faces[indice_face].neighbor[direction(indice_vertex)];
    }

    // Mesh structures manipulations
    // 2D Only with straight line walk
    // CM5
    unsigned int identify_point_face(const Vertices &point)
    {

        for (int i = 0; i < faces.size(); i++)
        {
            // std::cout<<"crufaceis"<< i<<std::endl;
            if (in_triangle_test_2d(*this, i, point) >= 0)
            {
                //   std::cout << "Correct face is" << i<< " " << faces[i].vertices[0]<< faces[i].vertices[1] << faces[i].vertices[2]<<    std::endl;
                return i;
            }
        }
        return static_cast<unsigned int>(-1);
    }
    inline bool edgeCoherence(Edges edge);
    bool edgeCoherence(Edges edge, unsigned int face1, unsigned int face2);
    // Insertion must be within the convex hull
    // Naive insertion mainlyjust oop through the convex hull to llok for hte correct position

    Faces insert_point_convexless(const unsigned int &new_point, unsigned int &vertices_face);

    friend void lawson(Mesh &mesh);

    // Pour un triangle le cercle circonscrit à une arête à son point opposé hors du delaunay
    //
    void flip_edge(Edges &edge_info);

    bool isDelaunay(edges edge, unsigned int shared_face_indx);
    bool isDelaunay(Edges edge);

    void incremental_triangulate(Mesh &mesh);
    void incremental_triangulate2(Mesh &mesh);
    void extractEdges(std::queue<Edges> &edge_queue);
    void extractEdgesFromFace(std::queue<Edges> &edge_queue, EdgeSet &edge_set, unsigned int &face, const Faces &back_up);
    void extractEdgesFromFace(std::queue<Edges> &edge_queue, EdgeSet &edge_set, unsigned int &face);

    void extractFacesEdge(std::queue<Edges> &edge_queue, Edges edge_info);

    void split_triangle(unsigned int vertice_indx, unsigned int &new_vertices_face);
    /////////////////////////////////////// TP3
    template <typename T>
    T compute_laplacian(unsigned int indice, const std::vector<T> &curr_weigh);
    template <typename T>
    T compute_laplacian_with_function(unsigned int indice, std::function<T(const Mesh &, unsigned &indice_a, unsigned &indice_b)> function) const;

    std::vector<Vertices> compute_mesh_normal();
    std::vector<Vertices> compute_mesh_normal_test();
    std::vector<float> compute_mean_curvature_f();
    std::vector<Vertices> compute_laplacian_vects() const;

    void mesh_heat_diffusion(float time_step = common_time_step);
    ////////////////Iterator
    struct Iterator_Face
    {
        Iterator_Face() = default;

        Iterator_Face(Faces *ptr) : m_ptr(ptr) {}

        Faces &operator*() const { return *m_ptr; }
        Faces *operator->() { return m_ptr; }
        Iterator_Face &operator++()
        {
            m_ptr++;
            return *this;
        }
        Iterator_Face operator++(int)
        {
            Iterator_Face tmp = *this;
            ++(*this);
            return tmp;
        }
        friend bool operator==(const Iterator_Face &a, const Iterator_Face &b) { return a.m_ptr == b.m_ptr; };
        friend bool operator!=(const Iterator_Face &a, const Iterator_Face &b) { return a.m_ptr != b.m_ptr; };

    private:
        Faces *m_ptr;
    };

    Iterator_Face faces_begin() { return Iterator_Face(&faces[0]); }
    Iterator_Face faces_end() { return Iterator_Face(&faces[(faces.size())]); }

    struct Iterator_Vertice
    {
        Iterator_Vertice() = default;

        Iterator_Vertice(Vertices *ptr) : m_ptr(ptr) {}

        Vertices &operator*() const { return *m_ptr; }
        Vertices *operator->() { return m_ptr; }
        Iterator_Vertice &operator++()
        {
            m_ptr++;
            return *this;
        }
        Iterator_Vertice operator++(int)
        {
            Iterator_Vertice tmp = *this;
            ++(*this);
            return tmp;
        }
        friend bool operator==(const Iterator_Vertice &a, const Iterator_Vertice &b) { return a.m_ptr == b.m_ptr; };
        friend bool operator!=(const Iterator_Vertice &a, const Iterator_Vertice &b) { return a.m_ptr != b.m_ptr; };

    private:
        Vertices *m_ptr;
    };

    Iterator_Vertice vertices_begin() { return Iterator_Vertice(&vertices[0]); }
    Iterator_Vertice vertices_end() { return Iterator_Vertice(&vertices[(vertices.size())]); }

    struct Circulator_Face
    {
        Circulator_Face() = default;

        Circulator_Face(std::vector<unsigned> faces, unsigned p_current_face, unsigned p_vertex_anchor) : m_ptr(faces), current_face_index(p_current_face), vert_index(p_vertex_anchor)
        {
        }
        unsigned end()
        {
            return m_ptr[m_ptr.size() - 1];
        }

        unsigned size()
        {
            return m_ptr.size();
        }

        unsigned operator*() const { return m_ptr[current_face_index]; }

        // Turn countercklockwise
        unsigned &operator++()
        {
            current_face_index = (current_face_index + 1) % (m_ptr.size());
            return m_ptr[current_face_index];
        }
        // Turn clockwise
        unsigned operator++(int)
        {
            unsigned tmp = current_face_index;
            current_face_index = (current_face_index + 1) % (m_ptr.size());
            return m_ptr[tmp];
        }

        friend bool operator==(const Circulator_Face &a, const Circulator_Face &b)
        {
            // return &a.m_ptr == &b.m_ptr;
            return (a.m_ptr.size() == b.m_ptr.size()) && (a.current_face_index == b.current_face_index) && (a.vert_index == b.vert_index);
        };
        friend bool operator!=(const Circulator_Face &a, const Circulator_Face &b)
        {
            // return &a.m_ptr != &b.m_ptr;
            return !((a.m_ptr.size() == b.m_ptr.size()) && (a.current_face_index == b.current_face_index) && (a.vert_index == b.vert_index));
        };

    private:
        // Faces
        std::vector<unsigned> m_ptr; // Or directly get face
        unsigned current_face_index;
        unsigned vert_index;
    };

    Circulator_Face incident_faces(unsigned &vertices_indices) const;
    // An incident faces designed to handle the convex hull better
    Circulator_Face incident_faces_convex(unsigned &vertices_indices) const;

    ////////////////////////////////IDK

    struct Circulator_Vertices
    {
        Circulator_Vertices() = default;

        Circulator_Vertices(std::vector<unsigned> vertices, unsigned p_current_vertices, unsigned p_vertex_anchor)
            : m_ptr(vertices), current_vertices(p_current_vertices), vert_index(p_vertex_anchor)
        {
        }

        unsigned operator*() const { return m_ptr[current_vertices]; }
        // Turn countercklockwise
        unsigned &operator++()
        {
            current_vertices = (current_vertices + 1) % (m_ptr.size());
            return m_ptr[current_vertices];
        }
        // Turn clockwise
        unsigned operator++(int)
        {
            unsigned tmp = current_vertices;
            current_vertices = (current_vertices + 1) % (m_ptr.size());
            return m_ptr[tmp];
        }

        friend bool operator==(const Circulator_Vertices &a, const Circulator_Vertices &b)
        {
            return (a.m_ptr.size() == b.m_ptr.size()) && (a.current_vertices == b.current_vertices) && (a.vert_index == b.vert_index);
        }
        friend bool operator!=(const Circulator_Vertices &a, const Circulator_Vertices &b)
        {
            return ((a.m_ptr.size() == b.m_ptr.size()) && (a.current_vertices == b.current_vertices) && (a.vert_index == b.vert_index));
        };

    private:
        // Faces
        std::vector<unsigned> m_ptr; // Or directly get face
        unsigned current_vertices;   // Index in the table
        unsigned vert_index;         // Index of the vertices the circulator was created rom
    };

    Circulator_Vertices incident_vertices(unsigned &vertices_indices) const;
};

// Move to Mesh
unsigned getNeighbors(const Faces &curr_face, unsigned &indice, std::function<unsigned(const unsigned &)> direction)
{
    // Return the face opposed to local indices
    return curr_face.neighbor[direction(indice)];
}

// Function handling removal and rebinding of vertices
// Probably to put in "vertices simplification function"

using edges_face = std::pair<unsigned, unsigned>;

float orientation_test_2d(const Vertices &vert1,
                          const Vertices &vert2, const Vertices &vert3)
{
    // Crossp rudct 2D ver1, ver2 and vert 1,vert3

    return (((vert2.x - vert1.x) * (vert3.y - vert1.y)) -
            ((vert2.y - vert1.y) * (vert3.x - vert1.x)));
    // Also determine which slop between vert2vert1is the biggst
    // 0 >  counter clockwise , and vert3 is on the left of vert1
    //== 0 They are collineeare
    //< 0
}

float in_triangle_test_2d(const Mesh &mesh, const unsigned int &face, const Vertices &point)
{
    unsigned vert0 = (mesh.getFace(face)).vertices[0];
    unsigned vert1 = (mesh.getFace(face)).vertices[1];
    unsigned vert2 = (mesh.getFace(face)).vertices[2];

    // Signed area abp
    float sign_area_edgea = orientation_test_2d(mesh.getVertice(vert0),
                                                mesh.getVertice(vert1), point);
    // Signed area bcp
    float sign_area_edgeb = orientation_test_2d(mesh.getVertice(vert1),
                                                mesh.getVertice(vert2), point);

    // Signed area cap
    float sign_area_edgec = orientation_test_2d(mesh.getVertice(vert2),
                                                mesh.getVertice(vert0), point);

    if (sign_area_edgea == 0 || sign_area_edgeb == 0 || sign_area_edgec == 0)
    {
        return 0;
    }

    // TODO recheck
    return (sign_area_edgea > 0 && sign_area_edgeb > 0 && sign_area_edgec > 0) ||
                   (sign_area_edgea < 0 && sign_area_edgeb < 0 && sign_area_edgec < 0)
               ? 1 // Inside
               : -1;
}

float in_triangle_test_2d(std::vector<Vertices> &vertices, const Faces &face, unsigned int &point)
{
    unsigned vert0 = face.vertices[0];
    unsigned vert1 = face.vertices[1];
    unsigned vert2 = face.vertices[2];

    // Signed area abp
    float sign_area_edgea = orientation_test_2d(vertices[vert0],
                                                vertices[vert1], vertices[point]);
    // Signed area bcp
    float sign_area_edgeb = orientation_test_2d(vertices[vert1],
                                                vertices[vert2], vertices[point]);

    // Signed area cap
    float sign_area_edgec = orientation_test_2d(vertices[vert2],
                                                vertices[vert0], vertices[point]);

    if (sign_area_edgea == 0 || sign_area_edgeb == 0 || sign_area_edgec == 0)
    {
        return 0;
    }

    // TODO recheck
    return (sign_area_edgea > 0 && sign_area_edgeb > 0 && sign_area_edgec > 0) ||
                   (sign_area_edgea < 0 && sign_area_edgeb < 0 && sign_area_edgec < 0)
               ? 1 // Inside
               : -1;
}
